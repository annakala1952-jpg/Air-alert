const API="https://tryvoha.online/api/v1",POLL_MS=45000,$=id=>document.getElementById(id),player=$("audioPlayer");
let regions=[],previous={kyiv:null,nem:null},soundData={},busy=false;
function connection(ok,msg){$("connectionDot").className="dot "+(ok?"green":"red");$("connectionText").textContent=msg}
function parseRegions(d){if(Array.isArray(d))return d;if(Array.isArray(d?.regions))return d.regions;if(Array.isArray(d?.data))return d.data;throw Error("Неизвестный формат списка регионов")}
function findRegion(re,type){let a=regions.filter(r=>re.test([r.name_uk,r.name_en,r.slug].join(" ")));return a.find(r=>!type||r.type===type)||a[0]||null}
function stateFor(slug,alerts){if(!slug)return{state:"unknown",detail:"Не удалось определить регион в справочнике"};let a=alerts.filter(x=>x.slug===slug);if(!a.length)return{state:"calm",detail:"Активных событий для региона не получено"};if(a.some(x=>x.level==="red"))return{state:"alert",detail:"Активная тревога / ракетная угроза"};return{state:"warning",detail:"Зафиксирована угроза БпЛА (жёлтый уровень)"}}
function paint(id,v){let c=$(id+"Card"),s=$(id+"Status"),d=$(id+"Detail");c.classList.remove("alert","warning");s.className="status";if(v.state==="alert"){c.classList.add("alert");s.classList.add("alert");s.textContent="ТРЕВОГА"}else if(v.state==="warning"){c.classList.add("warning");s.classList.add("warning");s.textContent="УГРОЗА БПЛА"}else s.textContent=v.state==="calm"?"СПОКОЙНО":"НЕТ ДАННЫХ";d.textContent=v.detail}
async function playSound(key){if(!soundData[key])return;try{player.pause();player.src=soundData[key];player.currentTime=0;await player.play()}catch(e){$("soundMessage").textContent="Не удалось воспроизвести звук: "+e.message}}
function transition(key,old,v,label){if(!old||old==="unknown"||v.state==="unknown"||old===v.state)return;if(v.state==="alert"||v.state==="warning"){playSound(key+"_alarm");notify("AIR ALERT UA — "+label,v.state==="alert"?"Объявлена тревога":"Зафиксирована угроза БпЛА")}else if(v.state==="calm"){playSound(key+"_end");notify("AIR ALERT UA — "+label,"Отбой / активных событий не найдено")}}
function notify(title,body){if("Notification"in window&&Notification.permission==="granted"){try{new Notification(title,{body,icon:"icon.svg"})}catch(e){}}}
async function update(){if(busy)return;busy=true;try{
if(!regions.length)regions=parseRegions(await(await fetch(API+"/regions",{cache:"no-store"})).json());
let p=await(await fetch(API+"/alerts",{cache:"no-store"})).json();if(!Array.isArray(p?.alerts))throw Error("API вернул неполный список тревог");
let kr=findRegion(/(м\.?\s*київ|kyiv city|kyiv-city)/i),nr=findRegion(/(бучанський район|buchanskyi district|buchanskii-raion|buchanskyi-raion)/i,"district")||findRegion(/(бучанський район|buchanskyi district|buchanskyi-raion)/i);
let k=stateFor(kr?.slug,p.alerts),n=stateFor(nr?.slug,p.alerts);
transition("kyiv",previous.kyiv,k,"Киев");transition("nem",previous.nem,n,"Немешаево");previous={kyiv:k.state,nem:n.state};paint("kyiv",k);paint("nem",n);
if(nr)$("nemDetail").textContent=n.detail+" · данные Бучанского района, не точечно по посёлку";
$("updated").textContent=new Date().toLocaleTimeString("ru-RU");connection(true,"Данные обновлены")
}catch(e){connection(false,"Нет связи: "+e.message);if(!previous.kyiv)paint("kyiv",{state:"unknown",detail:"Не удалось получить данные"});if(!previous.nem)paint("nem",{state:"unknown",detail:"Не удалось получить данные"})}finally{busy=false}}
function soundMessage(){let n=Object.keys(soundData).length;$("soundMessage").textContent=n?`Сохранено звуков: ${n} из 4. Нажми ▶ для проверки.`:"Звуки ещё не выбраны."}
try{soundData=JSON.parse(localStorage.getItem("airalert_sounds")||"{}")}catch(e){soundData={}}
for(let key of ["kyiv_alarm","kyiv_end","nem_alarm","nem_end"]){$(key).addEventListener("change",e=>{let f=e.target.files?.[0];if(!f)return;if(f.size>2*1024*1024){$("soundMessage").textContent="Файл больше 2 МБ. Выбери короткий звук до 2 МБ.";return}let r=new FileReader();r.onload=()=>{soundData[key]=r.result;try{localStorage.setItem("airalert_sounds",JSON.stringify(soundData));soundMessage()}catch(err){$("soundMessage").textContent="Не хватает памяти для сохранения звука. Выбери файл поменьше."}};r.readAsDataURL(f)})}
document.querySelectorAll("[data-play]").forEach(b=>b.addEventListener("click",()=>playSound(b.dataset.play)));
$("refresh").addEventListener("click",update);
$("notifyBtn").addEventListener("click",async()=>{if(!("Notification"in window)){$("soundMessage").textContent="Уведомления не поддерживаются.";return}let p=await Notification.requestPermission();$("notifyBtn").textContent=p==="granted"?"Уведомления включены":"Разрешение не выдано"});
if("serviceWorker"in navigator&&location.protocol.startsWith("http"))navigator.serviceWorker.register("./sw.js").catch(()=>{});
soundMessage();update();setInterval(update,POLL_MS);
